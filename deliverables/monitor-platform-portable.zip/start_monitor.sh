#!/bin/bash
# 监测平台启动脚本（便携版）
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "🚀 监测平台启动中..."
echo ""

# 检查Python
if ! command -v python3 &> /dev/null; then
    echo "❌ 错误: 未找到Python3"
    echo "   请安装Python 3.8+: https://www.python.org/downloads/"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
echo "✅ 检测到Python $PYTHON_VERSION"

# 创建虚拟环境（如果不存在）
if [ ! -d "venv" ]; then
    echo "📦 创建虚拟环境..."
    python3 -m venv venv
fi

# 激活虚拟环境
source venv/bin/activate

# 安装依赖
echo "📦 安装依赖..."
pip install -q -r monitor_platform/requirements.txt

# 启动服务
echo ""
echo "✅ 监测平台启动成功!"
echo ""
echo "   Web界面:   http://localhost:8000"
echo "   API文档:   http://localhost:8000/docs"
echo "   WebSocket: ws://localhost:8765"
echo ""
echo "   按 Ctrl+C 停止服务"
echo ""

python3 monitor_platform/server.py
