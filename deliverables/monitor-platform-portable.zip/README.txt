监测平台 V1.7 便携包
====================

文件名: monitor-platform-portable.zip

目录结构:
  server.py           - 监测平台主程序
  requirements.txt    - Python依赖
  start_monitor.sh    - Linux/Mac启动脚本
  start_monitor.bat   - Windows启动脚本
  README.txt          - 本文件

部署步骤:
  Linux:
    unzip monitor-platform-portable.zip
    cd monitor-platform
    chmod +x start_monitor.sh
    ./start_monitor.sh
  
  Windows:
    解压到目录（如 D:\monitor-platform）
    双击运行 start_monitor.bat

访问地址:
  Web: http://localhost:8000
  API: http://localhost:8000/docs
  WS:  ws://localhost:8765/ws
