Monitor Platform Portable Package
==================================

Version: V1.7
Created: 2026-08-20 17:44:19

Quick Start:
  Linux/macOS: ./start_monitor.sh
  Windows:     start_monitor.bat

Access:
  Web: http://localhost:8000
  API: http://localhost:8000/docs
  WS:  ws://localhost:8765

Requirements:
  - Python 3.8+
  - No GPU required
