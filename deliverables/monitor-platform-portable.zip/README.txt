监测平台便携部署包
==================

版本: V1.7
创建时间: 2026-08-20 15:22:42
依赖大小: 约2.5MB

## 启动步骤

### Linux/macOS
```bash
# 解压
unzip monitor-platform-portable.zip
cd monitor-platform

# 启动（自动创建虚拟环境）
./start_monitor.sh
```

### Windows
```cmd
:: 解压
expand-archive -Path monitor-platform-portable.zip -DestinationPath .

:: 启动
start_monitor.bat
```

## 访问地址
- Web界面: http://localhost:8000
- API文档: http://localhost:8000/docs
- WebSocket: ws://localhost:8765

## 系统要求
- Python 3.8+
- 无GPU要求
- 无CUDA要求

## 网络配置
确保机器狗与本机在同一网络，修改config/inspection_config.yaml中的server_url。

## 故障排查
- 端口被占用: 修改server.py中的WS_PORT/HTTP_PORT
- 连接失败: 检查防火墙设置，允许8000/8765端口
