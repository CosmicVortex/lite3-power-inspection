@echo off
chcp 65001 >nul
echo.
echo 🚀 监测平台启动中...
echo.

:: 检查Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ 错误: 未找到Python
    echo    请安装Python 3.8+: https://www.python.org/downloads/
    pause
    exit /b 1
)

python --version
echo.

:: 创建虚拟环境
if not exist "venv" (
    echo 📦 创建虚拟环境...
    python -m venv venv
)

:: 激活虚拟环境
call venv\Scripts\activate.bat

:: 安装依赖
echo 📦 安装依赖...
pip install -q -r monitor_platform\requirements.txt

:: 启动服务
echo.
echo ✅ 监测平台启动成功!
echo.
echo    Web界面:   http://localhost:8000
echo    API文档:   http://localhost:8000/docs
echo    WebSocket: ws://localhost:8765
echo.
echo    按 Ctrl+C 停止服务
echo.

python monitor_platform/server.py
pause
